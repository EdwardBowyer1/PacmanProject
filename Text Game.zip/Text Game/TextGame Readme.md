# PacmanProject
Cpsc 233 Pacman

To run the Text Game, download the package and if using eclipse
create a new project and import all the files. Run the java file 
TextGame and the demo shuold run if all classes are imported.

For console, navigate to the location of the files, compile TextGame.java,
and then run TextGame.class. 

Controls: w, a, s, d for up, left, down, right, respectively.

