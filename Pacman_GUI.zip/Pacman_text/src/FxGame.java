

import java.util.Scanner;


import javafx.application.*;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;

public class FxGame extends Application{
	//loading pacman GIF from constants to imageView class
	ImageView iView = new ImageView(Constants.GIFPacRight);
	Pane root = new Pane(); 
	

	private boolean isRunning;

	
	
	public void setIsRunning(boolean a)
	{
		isRunning = a;
	}

	public boolean getIsRunning()
	{
		return isRunning;
	}

	public static void main(String[] args) {
		
		Application.launch(args);
		

	}
	public void movePac(double x, double y)
	{
		double OGX = iView.getX();
		double OGY = iView.getY();
		if((OGX + x)>=0 && (OGY + y)>=0 && (OGY + y)<=Constants.screenHeight && (OGX + 2*x)<=Constants.screenWidth)
		{
			iView.setX(OGX + x);
			iView.setY(OGY + y);
		}
		root.getChildren().add(iView);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
	
        Location.initScreenDimensions();
       
        
		double ScreenW = Constants.screenWidth;
		double ScreenH = Constants.screenHeight;
		FxGame myapp = new FxGame();
		
		
		primaryStage.setTitle("Pacman Demo2");
		
	
		
	

		
		//setting dimensions of pacman GIF
		iView.setFitHeight(Constants.cellHeight); 
	    iView.setFitWidth(Constants.cellWidth); 
	    
	    //Placing pacman in centre of screen
		iView.setX((ScreenW-Constants.cellWidth)/2);
		iView.setY((ScreenH-Constants.cellHeight)/2);
		
		 //iView.setPreserveRatio(true);  
		 
		root.getChildren().add(iView);
		
		Map m1 = new Map();

		root.setStyle("-fx-background-color: black");
		
//		BackgroundFill myBF = new BackgroundFill(Color.BLACK, new CornerRadii(1),
//		         new Insets(0.0,0.0,0.0,0.0));// or null for the padding
//		//then you set to your node or container or layout
//		root.setBackground(new Background(myBF));
		
		Scene scene = new Scene(root,ScreenW,ScreenH);
	    primaryStage.setScene(scene);
		
			root.setOnKeyPressed(event -> {
				root.getChildren().clear();
    		
    		if (event.getCode() == KeyCode.UP)
    		{
    			iView.setRotate(-90);
    			movePac(0, -Constants.cellHeight);    			
    		}
    		else if (event.getCode() == KeyCode.DOWN)
    		{
    			iView.setRotate(90);
    			movePac(0, Constants.cellHeight);
    		}
    		else if (event.getCode() == KeyCode.LEFT)
    		{	
    			iView.setRotate(180);
    			movePac(-Constants.cellWidth, 0);
    		}
    		else if (event.getCode() == KeyCode.RIGHT)
    		{
    			iView.setRotate(0);
    			movePac(Constants.cellWidth,0);
    		}
    		  //event.consume();
    	});
			iView.setFocusTraversable(true);
			
			
		
	
			


	        primaryStage.show();
		}
    
        
	}


