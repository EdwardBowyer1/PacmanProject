import javafx.scene.*;

public class Cell extends GameObject{
	
	private int type;
	private Node node;
	
	public Cell(Location location, int type) {
		super(location);
		this.type = type;
		
		// TODO Auto-generated constructor stub
	}

	
	//write the code to return the node in the form of obstacle empty or food
	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
